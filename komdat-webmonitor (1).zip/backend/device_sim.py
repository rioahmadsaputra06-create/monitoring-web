
import random, time
from typing import List, Dict

class DeviceSimulator:
    def __init__(self, device_count=3):
        self.devices: List[Dict] = []
        for i in range(device_count):
            dev = {
                "id": f"dev-{i+1}",
                "name": f"Device-{i+1}",
                "ip": f"192.168.1.{10 + i}",
                "status": "online",
                "bandwidth_tx_kbps": 0.0,
                "bandwidth_rx_kbps": 0.0,
                "last_change": time.time(),
            }
            self.devices.append(dev)

    def step(self) -> List[Dict]:
        out = []
        for d in self.devices:
            if random.random() < 0.03:
                d["status"] = "offline" if d["status"] == "online" else "online"
                d["last_change"] = time.time()
            if d["status"] == "offline":
                d["bandwidth_tx_kbps"] = 0.0
                d["bandwidth_rx_kbps"] = 0.0
            else:
                base_tx = random.uniform(50, 800)
                base_rx = random.uniform(30, 500)
                jitter = random.uniform(-30, 30)
                d["bandwidth_tx_kbps"] = max(0.0, base_tx + jitter)
                d["bandwidth_rx_kbps"] = max(0.0, base_rx - jitter)
            d["timestamp"] = int(time.time())
            out.append(d.copy())
        return out
