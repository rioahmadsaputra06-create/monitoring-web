
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
import asyncio
from device_sim import DeviceSimulator
import time, json

app = FastAPI(title="Komdat Web Monitoring")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

sim = DeviceSimulator(3)

history = {d['id']: [] for d in sim.devices}
HISTORY_LIMIT = 500

class ConnectionManager:
    def __init__(self):
        self.active = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active:
            self.active.remove(websocket)

    async def broadcast(self, message: dict):
        text = json.dumps(message)
        for conn in list(self.active):
            try:
                await conn.send_text(text)
            except Exception:
                self.disconnect(conn)

manager = ConnectionManager()

async def producer():
    while True:
        updates = sim.step()
        for dev in updates:
            h = history.setdefault(dev["id"], [])
            h.append({
                "timestamp": dev["timestamp"],
                "status": dev["status"],
                "bandwidth_tx_kbps": dev["bandwidth_tx_kbps"],
                "bandwidth_rx_kbps": dev["bandwidth_rx_kbps"],
            })
            if len(h) > HISTORY_LIMIT:
                h.pop(0)
            await manager.broadcast({"type":"device_update","device":dev})
        await asyncio.sleep(1)

@app.on_event("startup")
async def startup_event():
    asyncio.create_task(producer())

@app.get("/")
async def root():
    return {"message":"Komdat Web Monitoring API running."}

@app.get("/devices")
async def list_devices():
    return {"devices": sim.devices}

@app.get("/history/{device_id}")
async def get_history(device_id: str, limit: int=100):
    h = history.get(device_id, [])
    return {"device_id": device_id, "history": h[-limit:]}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        await websocket.send_text(json.dumps({"type":"initial","devices": sim.devices}))
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)
