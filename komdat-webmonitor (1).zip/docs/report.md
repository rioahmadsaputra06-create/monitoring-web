
# Laporan Tugas - Analisis Protokol Komunikasi Data dan Simulasi Transfer Data Client–Server

**Mata Kuliah:** Komunikasi Data  
**Nama:** (isi nama)  
**NIM:** (isi NIM)  
**Tanggal:** (isi tanggal)

## 1. Pendahuluan
Laporan ini menjelaskan implementasi aplikasi Web Monitoring untuk menganalisis status perangkat jaringan secara real-time. Aplikasi terdiri dari backend (FastAPI) yang mensimulasikan perangkat dan mengirim update melalui WebSocket, serta frontend yang menampilkan data dalam bentuk tabel dan grafik.

## 2. Tujuan
- Membangun aplikasi monitoring real-time.
- Menyediakan endpoint REST untuk data historis.
- Mengaplikasikan protokol komunikasi seperti WebSocket dan HTTP.

## 3. Metodologi & Implementasi
- **Simulator perangkat**: Menghasilkan status online/offline dan penggunaan bandwidth.
- **Backend**: FastAPI menyediakan endpoint `/devices`, `/history/{device_id}`, dan WebSocket `/ws`. Background task secara periodik memanggil simulator dan menyiarkan update.
- **Frontend**: HTML + Tailwind + Chart.js menerima pesan WebSocket dan merender tabel, log, serta grafik.

## 4. Arsitektur Sistem
Lihat file `docs/architecture.mmd` untuk diagram mermaid.

## 5. Pengujian
- Jalankan backend dan frontend kemudian pantau UI.
- Ambil tangkapan layar saat perangkat berganti status menjadi offline untuk memenuhi kriteria log/alert.

## 6. Kesimpulan
Template ini memenuhi spesifikasi tugas: monitoring 3 perangkat (simulasi), REST endpoint untuk histori, WebSocket untuk update real-time, dan frontend sederhana. Untuk pengembangan lebih lanjut, integrasikan SNMP/MQTT dan database histori.

