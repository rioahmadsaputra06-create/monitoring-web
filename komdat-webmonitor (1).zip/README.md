
# Komdat Web Monitoring - Final Package

**Mata Kuliah:** Komunikasi Data  
**Judul:** Analisis Protokol Komunikasi Data dan Simulasi Transfer Data Client–Server

## Konten Paket
- **backend/** : FastAPI backend dengan WebSocket dan simulator perangkat
- **frontend/** : Frontend HTML (Tailwind + Chart.js) menampilkan tabel, log, dan grafik
- **docs/** : Laporan tugas (Markdown) dan diagram mermaid

## Cara Menjalankan (Local)
1. Jalankan backend:
    ```bash
    cd backend
    python -m venv venv
    source venv/bin/activate   # atau venv\Scripts\activate untuk Windows
    pip install -r requirements.txt
    uvicorn main:app --reload --host 0.0.0.0 --port 8000
    ```
2. Jalankan frontend:
    - Opsi A: jalankan server statis dari folder frontend:
        ```
        cd ../frontend
        python -m http.server 8080
        ```
        buka `http://localhost:8080`
    - Opsi B: buka file `frontend/index.html` langsung (browser mungkin blokir beberapa fitur jika file://)
3. Ambil screenshot/rekaman: tabel, grafik real-time, log alert.

## Deliverable
- Source code (folder backend + frontend)
- README.md (this file)
- Laporan tugas (docs/report.md)
- Diagram arsitektur (docs/architecture.mmd)

## Catatan
- Untuk mengganti simulasi dengan SNMP/MQTT/ICMP nyata, ubah file `backend/device_sim.py`.
- Data histori disimpan in-memory. Untuk penyimpanan jangka panjang gunakan DB (InfluxDB/SQLite).
