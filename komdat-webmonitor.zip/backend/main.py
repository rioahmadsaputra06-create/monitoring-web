
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
import asyncio
from device_sim import get_devices_status

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.get("/history")
def history():
    return {"message": "Contoh data historis", "data": get_devices_status()}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    while True:
        data = get_devices_status()
        await websocket.send_json(data)
        await asyncio.sleep(2)
