
import random, time

def get_devices_status():
    devices=[
        {"name":"Router-1","ip":"192.168.1.1"},
        {"name":"Switch-1","ip":"192.168.1.2"},
        {"name":"AccessPoint","ip":"192.168.1.3"}
    ]
    result=[]
    for d in devices:
        result.append({
            "name": d["name"],
            "ip": d["ip"],
            "status": random.choice(["online","offline"]),
            "bandwidth": random.randint(10,100),
            "time": time.strftime("%H:%M:%S")
        })
    return result
